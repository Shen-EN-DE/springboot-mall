package com.example.demo.constent;

public enum ProductCategory {
	FOOD,
	CAR,
	BOOK
}
