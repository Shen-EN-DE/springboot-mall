package com.example.demo.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	//AuthenticationProvider 是用來做身份認證的元件，它是一個介面。在此給予「DaoAuthenticationProvider」，代表要依據 DB 中的資料來做認證。
	//AuthenticationProvider 會從 UserDetailsService 取得使用者資訊。而 BCryptPasswordEncoder 會將我們在畫面上輸入的密碼做加密，與 User 物件中的密碼密文（來自 DB）做比對。若相符，則認證通過。
	@Bean
	public AuthenticationProvider authenticationProvider(
			UserDetailsService userDetailsService,
			BCryptPasswordEncoder passwordEncoder
	){
		var provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(passwordEncoder);
		return provider;
		
	}
	
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
		http
			.authorizeRequests(registry -> registry
					.requestMatchers(HttpMethod.POST, "/user/register", "/user/login").permitAll()
					.requestMatchers("/public/**").permitAll()
					.requestMatchers("/users/**").hasAnyAuthority("ADMIN", "USER") //user login
					.requestMatchers("/admin/**").hasAuthority("ADMIN") // have a admin
					.anyRequest().authenticated()
			)
			.csrf(AbstractHttpConfigurer::disable)
			.formLogin();
		
//			.httpBasic();// 使用HTTP Basic認證 (根據實際需求可能需要更安全的配置如JWT或表單登入)
		
		return http.build();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();	
	}
	
	@Bean
	public TokenServer tokenServer(
			@Value("${security.jwt.key}") String key,
			@Value("${security.access-token-ttl-seconds}") int accessTokenTtilSeconds,
			AuthenticationProvider authenticationProvider
	) {
		var jwtSecretKey = Keys.hmacShaKeyFor(key.getBytes());
		var jwtParser = Jwts.parserBuilder().setSigningKey(jwtSecretKey).build();
		return new TokenServer(jwtSecretKey, jwtParser, accessTokenTtilSeconds, authenticationProvider);
	}
}
