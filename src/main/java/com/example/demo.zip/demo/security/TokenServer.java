package com.example.demo.security;

import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.dto.LoginResponse;
import com.example.demo.dto.UserLoginRequest;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;

public class TokenServer {
	private final Key secretKey;
	private final JwtParser jwtParser;
	private final int accessTokenTtilSeconds;
	private final AuthenticationProvider authenticationProvider;
	
	public TokenServer(Key jwtSecretKey, JwtParser jwtParser, int accessTokenTtilSeconds,
						AuthenticationProvider authenticationProvider) {
		this.secretKey = jwtSecretKey;
		this.jwtParser = jwtParser;
		this.accessTokenTtilSeconds = accessTokenTtilSeconds;
		this.authenticationProvider = authenticationProvider;
	}

	public LoginResponse createToken(UserLoginRequest request) {
		Authentication authToken = new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword());
		authToken = authenticationProvider.authenticate(authToken);
		
		UserDetails userDetails = (UserDetails) authToken.getPrincipal();
		String accessToken = createAccessToken(userDetails.getUsername());
		
		LoginResponse response = new LoginResponse();
		response.setAccessToken(accessToken);
		
		return response;
		
	}

	
	private String createAccessToken(String email) {
		//Effective time (ms)
        long expirationMillis = Instant.now()
                .plusSeconds(accessTokenTtilSeconds)
                .getEpochSecond()
                * 1000;
        
		
		//set standard and custom content
		Claims claims = Jwts.claims();
		claims.setSubject("Access Token");
		claims.setIssuedAt(new Date());
		claims.setExpiration(new Date(expirationMillis));
		claims.put("email", email);
		
		
		return Jwts.builder()
				.setClaims(claims)
				.signWith(secretKey)
				.compact();
	}
	
	public Map<String, Object>parseToken(String token){
		Claims claims = jwtParser.parseClaimsJws(token).getBody();
		return new HashMap<>(claims);
	}
	
	
}
